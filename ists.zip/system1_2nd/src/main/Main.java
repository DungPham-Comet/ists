package main;

import main.controller.MainController;

public class Main {

	public static void main(String[] args) {
		long startTime = System.nanoTime();
		MainController mainController = new MainController();
		mainController.run(args[0], args[1]);
		long endTime = System.nanoTime();
		System.out.println("Run Time: " + ((endTime - startTime) / 1000000) + "ms");
	}
	
	//C:\Users\PJ544116\IBM\rationalsdp\workspace\system1>java -cp "bin;C:/Program Files (x86)/IBM/SQLLIB/java/db2jcc4.jar" main.Main

}
