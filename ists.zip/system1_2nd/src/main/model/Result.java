package main.model;

public class Result {
	private int siyo;
	private String koujiNum;
	private String shohinCode;
	private int point;
	
	public Result(){
		
	}

	public Result(int siyo, String koujiNum, String shohinCode, int point) {
		this.siyo = siyo;
		this.koujiNum = koujiNum;
		this.shohinCode = shohinCode;
		this.point = point;
	}

	public int getSiyo() {
		return siyo;
	}

	public void setSiyo(int siyo) {
		this.siyo = siyo;
	}

	public String getKoujiNum() {
		return koujiNum;
	}

	public void setKoujiNum(String koujiNum) {
		this.koujiNum = koujiNum;
	}
	
	public String getShohinCode(){
		return shohinCode;
	}
	
	public void setShohinCode(String shohinCode){
		this.shohinCode = shohinCode;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}
	
	
}
