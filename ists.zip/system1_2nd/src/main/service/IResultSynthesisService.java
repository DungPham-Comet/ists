package main.service;

import java.util.List;

import main.dao.SiyoDAO;
import main.model.Result;
import main.model.UserCustomSiyo;

public interface IResultSynthesisService {
	SiyoDAO SIYODAO = new SiyoDAO();
	
	public List<Result> DataSynthesis(UserCustomSiyo userCustomSiyo);
}
