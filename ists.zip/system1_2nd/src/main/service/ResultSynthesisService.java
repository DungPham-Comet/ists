package main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import main.model.Result;
import main.model.UserCustomSiyo;

public class ResultSynthesisService implements IResultSynthesisService{
//	private SiyoDAO siyoDAO;
//	
//	public ResultSynthesisService(){
//		this.siyoDAO = new SiyoDAO();
//	}
	
	@Override
	public List<Result> DataSynthesis(UserCustomSiyo userCustomSiyo){
		Map<Integer, String> siyo_kouji = SIYODAO.getSiyoByShohinCode(userCustomSiyo.getShohinCode());
		List<Integer> siyo_ids = new ArrayList<Integer>(siyo_kouji.keySet());
		
		List<String> juto_codes = userCustomSiyo.getJutoCodes();
		
		Map<Integer, Integer> siyo_point = SIYODAO.finalResult(siyo_ids, juto_codes);
		
		List<Result> finalResults = new ArrayList<Result>();
		for (Integer siyo : siyo_point.keySet()){
			finalResults.add(new Result(siyo, siyo_kouji.get(siyo), userCustomSiyo.getShohinCode() , siyo_point.get(siyo)));
		}
		
		return finalResults;
	}
}
