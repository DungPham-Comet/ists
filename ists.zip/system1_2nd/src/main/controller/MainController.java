package main.controller;

import java.util.List;

import main.model.Result;
import main.model.UserCustomSiyo;
import main.service.ResultSynthesisService;
import main.util.CsvWriter;
import main.util.XmlReader;

public class MainController {
	public void run(String inputFileName, String outputFileName) {
//		Part1: Reading XML
	    XmlReader xmlReader = new XmlReader();
	    UserCustomSiyo userCustomSiyo = xmlReader.readXml("src/dataFiles/" + inputFileName + ".xml");

//		Part2: Gathering data
		ResultSynthesisService resultSynthesisService = new ResultSynthesisService();
		List<Result> finals = resultSynthesisService.DataSynthesis(userCustomSiyo);
		

//		Part3: Writing CSV
	    CsvWriter csvWriter = new CsvWriter();
	    csvWriter.writeResultToCsv("src/dataFiles/" + outputFileName + ".csv", finals);
	    System.out.println("Result export sucessfully on: " + "C:/Users/PJ544116/IBM/rationalsdp/workspace/system1/bin/dataFiles/" + outputFileName + ".csv");
		
	}
}
