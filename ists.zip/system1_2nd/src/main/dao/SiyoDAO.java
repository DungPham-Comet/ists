package main.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import main.util.DatabaseConnection;

public class SiyoDAO {
	
	public Map<Integer, String> getSiyoByShohinCode(String shohinCode){
		String SELECT_QUERY = "SELECT * FROM test.iv_siyo " +
								"WHERE SHOHIN_CD = ?";
        Map<Integer, String> siyo_kouji = new HashMap<Integer, String>();
        Connection conn;
        try {
            conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(SELECT_QUERY);
            ps.setString(1, shohinCode);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                siyo_kouji.put(rs.getInt("SIYO_ID"), rs.getString("KOUJI_NUM"));
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return siyo_kouji;
	}
	
	public Map<Integer, Integer> finalResult(List<Integer> siyo_ids, List<String> juto_codes){
      String SELECT_QUERY = "SELECT SIYO_ID, SUM(INTEGER(WEIGHTING)) AS POINT " +
      		"FROM test.iv_sych JOIN test.iv_juto_weight ON test.iv_sych.JUTO_CD = test.iv_juto_weight.JUTO_CD " +
      		"WHERE test.iv_sych.SIYO_ID IN (%s) AND test.iv_sych.JUTO_CD IN (%s) " +
      		"GROUP BY SIYO_ID " +
      		"ORDER BY POINT DESC";
      
      Map<Integer, Integer> siyo_point = new LinkedHashMap<Integer, Integer>();
      Connection conn;
      
      String siyo_ids_str = "";
      for (int siyo_id : siyo_ids) {
    	  siyo_ids_str += siyo_id + ",";
      }
      siyo_ids_str = siyo_ids_str.substring(0, siyo_ids_str.length() - 1);
      
      String juto_codes_str = "";
      for (String juto_code : juto_codes){
    	  juto_codes_str += "'" + juto_code + "'" + ",";
      }
      juto_codes_str = juto_codes_str.substring(0, juto_codes_str.length() - 1);
      
      SELECT_QUERY = String.format(SELECT_QUERY, siyo_ids_str, juto_codes_str);
      
      try {
    	  conn = DatabaseConnection.getConnection();
    	  PreparedStatement ps = conn.prepareStatement(SELECT_QUERY);
    	  ResultSet rs = ps.executeQuery();
    	  while (rs.next()) {
    		  siyo_point.put(rs.getInt("SIYO_ID"), rs.getInt("POINT"));
			}
    	  conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
      
      return siyo_point;
	}
	
	public Map<Integer, Map<String, Integer>> getJutoAndQuantity(List<Integer> siyo_ids){
		Map<String, Integer> jutoAndQuantity = new HashMap<String, Integer>();
		Map<Integer, Map<String, Integer>> siyoAndJutoAndQuantity = new HashMap<Integer, Map<String, Integer>>();
		
		String SELECT_QUERY = "SELECT siyo_id, test.IV_SYCH.juto_cd, COUNT(test.IV_SYCH.juto_cd) AS siyo_chk_quantity " +
				"FROM test.IV_SYCH " +
				"WHERE siyo_id IN (%s) " +
				"GROUP BY siyo_id, test.IV_SYCH.juto_cd;";
		
		Connection conn;
		
		String siyo_ids_str = "";
	    for (int siyo_id : siyo_ids) {
	  	  siyo_ids_str += siyo_id + ",";
	    }
	    siyo_ids_str = siyo_ids_str.substring(0, siyo_ids_str.length() - 1);
	    
	    SELECT_QUERY = String.format(SELECT_QUERY, siyo_ids_str);
	    
	    try {
			conn = DatabaseConnection.getConnection();
	    	PreparedStatement ps = conn.prepareStatement(SELECT_QUERY);
	    	ResultSet rs = ps.executeQuery();
	    	
	    	while (rs.next()){
	    		
	    	}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
		return siyoAndJutoAndQuantity;
	}
	
}