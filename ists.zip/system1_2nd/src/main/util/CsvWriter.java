package main.util;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import main.model.Result;

public class CsvWriter {
	public void writeResultToCsv(String path, List<Result> finals) {
		try {
			PrintWriter printWriter = new PrintWriter(path);
			printWriter.println("Kouji Number,Kishu,Point");
			
			for (Result record : finals){
				printWriter.print(record.getKoujiNum());
				printWriter.print(",");
				printWriter.print(record.getShohinCode());
				printWriter.print(",");
				printWriter.print(record.getPoint());
				printWriter.println();
			}
			
			printWriter.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
}
